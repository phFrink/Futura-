__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/9b29f836e1629fc1.js",
  "static/chunks/turbopack-c414669b728b7a2e.js"
])
