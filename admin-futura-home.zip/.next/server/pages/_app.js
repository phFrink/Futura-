var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__70a73b34._.js")
R.m("[project]/node_modules/next/app.js [ssr] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/app.js [ssr] (ecmascript)").exports
