module.exports = [
"[project]/.next-internal/server/app/api/upload/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/punycode [external] (punycode, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("punycode", () => require("punycode"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/src/lib/supabase.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
;
// Get environment variables
const supabaseUrl = ("TURBOPACK compile-time value", "https://wwupnerwfrecqqrdenxi.supabase.co");
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind3dXBuZXJ3ZnJlY3FxcmRlbnhpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUzNDI4NjQsImV4cCI6MjA3MDkxODg2NH0.7DyLDOFnOjJ6h4cnOMVjKY3k55nPeAGEptAF8niPnb8");
// Function to create Supabase client safely
function createSupabaseClient() {
    // Only log and validate in runtime, not during build
    if ("TURBOPACK compile-time truthy", 1) {
        console.log("🔧 Supabase Configuration:");
        console.log("URL:", ("TURBOPACK compile-time truthy", 1) ? "✅ Set" : "TURBOPACK unreachable");
        console.log("Anon Key:", ("TURBOPACK compile-time truthy", 1) ? "✅ Set" : "TURBOPACK unreachable");
    }
    // Don't create client if environment variables are missing
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseAnonKey, {
        auth: {
            autoRefreshToken: true,
            persistSession: true,
            detectSessionInUrl: false
        },
        global: {
            headers: {
                'X-Client-Info': 'pet-portal-client'
            }
        }
    });
}
const supabase = createSupabaseClient();
// Test connection and URL accessibility
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
}),
"[project]/src/lib/storage.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteFileFromStorage",
    ()=>deleteFileFromStorage,
    "getFilePublicUrl",
    ()=>getFilePublicUrl,
    "uploadFileToStorage",
    ()=>uploadFileToStorage,
    "validateFile",
    ()=>validateFile
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
;
;
// Create admin client for uploads (bypasses RLS)
function createAdminClient() {
    const url = ("TURBOPACK compile-time value", "https://wwupnerwfrecqqrdenxi.supabase.co");
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceKey) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, serviceKey, {
        auth: {
            autoRefreshToken: false,
            persistSession: false
        }
    });
}
async function uploadFileToStorage(file, bucket, folder = '', filename = null) {
    try {
        console.log('🔄 Starting file upload to Supabase Storage...');
        console.log('File info:', {
            name: file.name,
            size: file.size,
            type: file.type
        });
        console.log('Upload params:', {
            bucket,
            folder,
            filename
        });
        // Use admin client for uploads to bypass RLS
        const adminClient = createAdminClient();
        if (!adminClient) {
            const error = 'Admin client not initialized - check SUPABASE_SERVICE_ROLE_KEY';
            console.error('❌', error);
            return {
                success: false,
                error
            };
        }
        console.log('🔑 Using service role key for upload (bypasses RLS)');
        // Check if regular client is available for public URL generation
        if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabase"]) {
            const error = 'Supabase client not initialized - check environment variables';
            console.error('❌', error);
            return {
                success: false,
                error
            };
        }
        // Generate filename if not provided
        if (!filename) {
            const timestamp = Date.now();
            const randomSuffix = Math.round(Math.random() * 1e9);
            const extension = file.name.split('.').pop();
            filename = `${timestamp}-${randomSuffix}.${extension}`;
        }
        // Construct file path
        const filePath = folder ? `${folder}/${filename}` : filename;
        console.log('📁 Full file path:', filePath);
        // Convert file to proper format for Supabase
        const fileBuffer = await file.arrayBuffer();
        console.log('📄 File converted to buffer, size:', fileBuffer.byteLength);
        // Upload file to Supabase Storage using admin client
        console.log('☁️ Uploading to Supabase Storage with admin privileges...');
        const { data, error } = await adminClient.storage.from(bucket).upload(filePath, fileBuffer, {
            contentType: file.type,
            cacheControl: '3600',
            upsert: false // Don't overwrite existing files
        });
        if (error) {
            console.error('❌ Supabase storage upload error:', error);
            console.error('Error details:', {
                message: error.message,
                statusCode: error.statusCode,
                error: error.error
            });
            return {
                success: false,
                error: `Storage error: ${error.message}`
            };
        }
        console.log('✅ Upload successful:', data);
        // Get public URL
        const { data: { publicUrl } } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabase"].storage.from(bucket).getPublicUrl(filePath);
        console.log('🔗 Public URL generated:', publicUrl);
        return {
            success: true,
            data: {
                path: data.path,
                fullPath: data.fullPath,
                publicUrl: publicUrl,
                filename: filename
            }
        };
    } catch (error) {
        console.error('❌ Storage upload error:', error);
        console.error('Error stack:', error.stack);
        return {
            success: false,
            error: `Upload failed: ${error.message}`
        };
    }
}
async function deleteFileFromStorage(bucket, filePath) {
    try {
        // Use admin client for deletions to bypass RLS
        const adminClient = createAdminClient();
        if (!adminClient) {
            throw new Error('Admin client not initialized - check SUPABASE_SERVICE_ROLE_KEY');
        }
        console.log('🗑️ Using service role key for deletion (bypasses RLS)');
        const { error } = await adminClient.storage.from(bucket).remove([
            filePath
        ]);
        if (error) {
            console.error('Delete error:', error);
            return {
                success: false,
                error: error.message
            };
        }
        return {
            success: true
        };
    } catch (error) {
        console.error('Storage delete error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}
function getFilePublicUrl(bucket, filePath) {
    if (!__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabase"]) {
        return null;
    }
    const { data } = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabase"].storage.from(bucket).getPublicUrl(filePath);
    return data.publicUrl;
}
function validateFile(file, options = {}) {
    const { allowedTypes = [
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/webp'
    ], maxSize = 5 * 1024 * 1024, minSize = 0 } = options;
    // Check file type
    if (!allowedTypes.includes(file.type)) {
        return {
            valid: false,
            error: `Invalid file type. Allowed types: ${allowedTypes.join(', ')}`
        };
    }
    // Check file size
    if (file.size > maxSize) {
        const maxSizeMB = Math.round(maxSize / (1024 * 1024));
        return {
            valid: false,
            error: `File too large. Maximum size: ${maxSizeMB}MB`
        };
    }
    if (file.size < minSize) {
        return {
            valid: false,
            error: `File too small. Minimum size: ${minSize} bytes`
        };
    }
    return {
        valid: true
    };
}
}),
"[project]/src/app/api/upload/route.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DELETE",
    ()=>DELETE,
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/storage.js [app-route] (ecmascript)");
;
;
async function POST(request) {
    try {
        const formData = await request.formData();
        const file = formData.get("profile");
        if (!file) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "No file uploaded"
            }, {
                status: 400
            });
        }
        // Validate file
        const validation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["validateFile"])(file, {
            allowedTypes: [
                "image/jpeg",
                "image/jpg",
                "image/png",
                "image/gif",
                "image/webp"
            ],
            maxSize: 5 * 1024 * 1024
        });
        if (!validation.valid) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: validation.error
            }, {
                status: 400
            });
        }
        // Generate unique filename
        const timestamp = Date.now();
        const randomSuffix = Math.round(Math.random() * 1e9);
        const extension = file.name.split(".").pop();
        const filename = `profile-${timestamp}-${randomSuffix}.${extension}`;
        // Upload to Supabase Storage
        console.log("🚀 Attempting upload to Supabase Storage...");
        const uploadResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["uploadFileToStorage"])(file, "uploads", "profiles", filename);
        if (!uploadResult.success) {
            console.error("❌ Upload to storage failed:", uploadResult.error);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "Failed to upload file to storage",
                details: uploadResult.error
            }, {
                status: 500
            });
        }
        console.log("✅ Upload successful!");
        // Return success response with file info
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            message: "File uploaded successfully",
            filename: uploadResult.data.filename,
            url: uploadResult.data.publicUrl,
            path: uploadResult.data.path,
            size: file.size,
            type: file.type
        }, {
            status: 200
        });
    } catch (error) {
        console.error("Upload error:", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Failed to upload file"
        }, {
            status: 500
        });
    }
}
async function GET() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        message: "Upload API endpoint. Use POST to upload images."
    }, {
        status: 200
    });
}
async function DELETE(request) {
    try {
        const { searchParams } = new URL(request.url);
        const filename = searchParams.get("filename");
        const filePath = searchParams.get("path"); // Full storage path
        if (!filename && !filePath) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "Filename or path is required"
            }, {
                status: 400
            });
        }
        // Security check - only allow deletion of profile images
        if (filename && (!filename.startsWith("profile-") || filename.includes("..") || filename.includes("/"))) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "Invalid filename"
            }, {
                status: 400
            });
        }
        // Construct storage path
        const storageFilePath = filePath || `profiles/${filename}`;
        // Delete from Supabase Storage
        const deleteResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deleteFileFromStorage"])("uploads", storageFilePath);
        if (!deleteResult.success) {
            console.error("Delete from storage failed:", deleteResult.error);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "Failed to delete file from storage"
            }, {
                status: 500
            });
        }
        console.log(`🗑️ Deleted profile image: ${storageFilePath}`);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            message: "File deleted successfully",
            filename: filename || storageFilePath
        }, {
            status: 200
        });
    } catch (error) {
        console.error("Delete error:", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Failed to delete file"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__c0a19368._.js.map