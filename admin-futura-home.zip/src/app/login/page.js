import LoginComponent from '@/components/features/login'
import React from 'react'

const LoginPage = () => {
  return (
   <LoginComponent/>
  )
}

export default LoginPage