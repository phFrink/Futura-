import React from 'react'
import LoginPage from './login/page'

const Page = () => {
  return (
    <LoginPage/>
  )
}

export default Page