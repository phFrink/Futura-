import LoginComponent from '@/components/features/login'
import Signup from '@/components/features/signup'
import React from 'react'

const LoginPage = () => {
  return (
   <Signup/>
  )
}

export default LoginPage